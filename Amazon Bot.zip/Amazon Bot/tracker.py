from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager
import time
import re
import os
import pandas as pd
from openpyxl import load_workbook, Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from datetime import datetime
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

# ===== CONFIG =====
PRODUCTS = [
    {"name": "Iphone",  "url": "https://www.amazon.in/dp/B0FQFQF6D1"},
    {"name": "Galaxy",  "url": "https://www.amazon.in/dp/B0DSKNQW8F?_encoding=UTF8&ref_=cct_cg_Budget_3c1&pf_rd_p=a584ac81-caea-4a96-919f-12816d7f4777&pf_rd_r=TEBDH98NPTDGZHYFVCGN"},
    {"name": "One+",    "url": "https://www.amazon.in/dp/B0FCMKSP7V?_encoding=UTF8&ref_=cct_cg_Budget_2a1&pf_rd_p=a584ac81-caea-4a96-919f-12816d7f4777&pf_rd_r=TEBDH98NPTDGZHYFVCGN"},
]

EXCEL_FILE  = "amazon_prices.xlsx"
SHEET_NAME  = "Price Tracker"

# ===== EMAIL CONFIG =====
# For Gmail: enable 2-Step Verification, then create an App Password at
# https://myaccount.google.com/apppasswords  (use that 16-char password below)
EMAIL_SENDER   = "rishabh.sisodiya@lagozon.com"       # ← change this
EMAIL_PASSWORD = "gucvurjvivaexcaq"     # ← 16-char Gmail App Password
EMAIL_RECEIVER = "rishabh.sisodiya@lagozon.com"   # ← where alerts go (can be same)

SMTP_HOST = "smtp.gmail.com"
SMTP_PORT = 587
# ==================

def get_price(url):
    options = Options()
    options.add_argument("--headless")
    options.add_argument("--start-maximized")
    driver = webdriver.Chrome(
        service=Service(ChromeDriverManager().install()),
        options=options
    )
    driver.get(url)
    WebDriverWait(driver, 15).until(
        EC.presence_of_element_located((By.TAG_NAME, "body"))
    )
    time.sleep(2)
    elements = driver.find_elements(By.XPATH, "//*[contains(text(),'₹')]")
    prices = []
    for el in elements:
        text  = el.text.strip()
        match = re.search(r"₹[\d,]+\.?\d*", text)
        if match:
            prices.append(match.group())
    driver.quit()
    if not prices:
        return None

    def to_number(p):
        return float(p.replace("₹", "").replace(",", ""))

    return to_number(max(prices, key=to_number))


def get_last_prices(product_names):
    """
    Read the Excel file and return the most recent price for each product.
    Returns a dict like {"Iphone": 79999.0, "Galaxy": None, ...}
    """
    last = {name: None for name in product_names}
    if not os.path.exists(EXCEL_FILE):
        return last
    try:
        df = pd.read_excel(EXCEL_FILE, sheet_name=SHEET_NAME, index_col=0)
        df.sort_index(inplace=True)
        if df.empty:
            return last
        # Drop today's row if it already exists so we compare against the previous day
        today = datetime.now().strftime("%Y-%m-%d")
        df = df[df.index != today]
        if df.empty:
            return last
        last_row = df.iloc[-1]
        for name in product_names:
            if name in last_row and pd.notna(last_row[name]):
                last[name] = float(last_row[name])
    except Exception as e:
        print(f"Warning: could not read previous prices — {e}")
    return last


def send_email_alert(drops):
    """
    drops: list of dicts with keys: name, url, old_price, new_price, saving, pct_drop
    """
    if not drops:
        return

    # ----- Build HTML body -----
    rows_html = ""
    for d in drops:
        rows_html += f"""
        <tr>
            <td style="padding:10px;border:1px solid #ddd;">{d['name']}</td>
            <td style="padding:10px;border:1px solid #ddd;color:#888;text-decoration:line-through;">₹{d['old_price']:,.2f}</td>
            <td style="padding:10px;border:1px solid #ddd;color:#27ae60;font-weight:bold;">₹{d['new_price']:,.2f}</td>
            <td style="padding:10px;border:1px solid #ddd;color:#e74c3c;">↓ {d['pct_drop']:.1f}%  (save ₹{d['saving']:,.2f})</td>
            <td style="padding:10px;border:1px solid #ddd;"><a href="{d['url']}" style="color:#2471a3;">Buy Now</a></td>
        </tr>"""

    html_body = f"""
    <html><body>
    <h2 style="color:#2F5597;font-family:Arial">🔔 Amazon Price Drop Alert</h2>
    <p style="font-family:Arial">Good news! The following products have dropped in price:</p>
    <table style="border-collapse:collapse;font-family:Arial;width:100%">
        <tr style="background:#2F5597;color:white">
            <th style="padding:10px;border:1px solid #ddd;">Product</th>
            <th style="padding:10px;border:1px solid #ddd;">Old Price</th>
            <th style="padding:10px;border:1px solid #ddd;">New Price</th>
            <th style="padding:10px;border:1px solid #ddd;">Saving</th>
            <th style="padding:10px;border:1px solid #ddd;">Link</th>
        </tr>
        {rows_html}
    </table>
    <p style="font-family:Arial;color:#888;font-size:12px">Tracked on {datetime.now().strftime("%Y-%m-%d %H:%M")}</p>
    </body></html>"""

    subject = f"🔔 Price Drop Alert — {', '.join(d['name'] for d in drops)}"

    msg = MIMEMultipart("alternative")
    msg["Subject"] = subject
    msg["From"]    = EMAIL_SENDER
    msg["To"]      = EMAIL_RECEIVER
    msg.attach(MIMEText(html_body, "html"))

    try:
        with smtplib.SMTP(SMTP_HOST, SMTP_PORT) as server:
            server.ehlo()
            server.starttls()
            server.login(EMAIL_SENDER, EMAIL_PASSWORD)
            server.sendmail(EMAIL_SENDER, EMAIL_RECEIVER, msg.as_string())
        print(f"✅ Email alert sent to {EMAIL_RECEIVER}")
    except Exception as e:
        print(f"❌ Failed to send email: {e}")


def apply_header_style(cell):
    cell.font      = Font(name="Arial", bold=True, color="FFFFFF")
    cell.fill      = PatternFill("solid", start_color="2F5597")
    cell.alignment = Alignment(horizontal="center", vertical="center")
    cell.border    = Border(
        left=Side(style="thin"), right=Side(style="thin"),
        top=Side(style="thin"),  bottom=Side(style="thin")
    )

def apply_data_style(cell, is_alternate_row=False):
    cell.font      = Font(name="Arial", size=10)
    cell.fill      = PatternFill("solid", start_color="DCE6F1" if is_alternate_row else "FFFFFF")
    cell.alignment = Alignment(horizontal="center")
    cell.border    = Border(
        left=Side(style="thin"), right=Side(style="thin"),
        top=Side(style="thin"),  bottom=Side(style="thin")
    )

def save_pivot_excel(today, today_prices):
    product_names = [p["name"] for p in PRODUCTS]

    if os.path.exists(EXCEL_FILE):
        try:
            df_pivot = pd.read_excel(EXCEL_FILE, sheet_name=SHEET_NAME, index_col=0)
            for name in product_names:
                if name not in df_pivot.columns:
                    df_pivot[name] = None
        except ValueError:
            print(f"Sheet '{SHEET_NAME}' not found. Creating fresh.")
            df_pivot = pd.DataFrame(columns=product_names)
            df_pivot.index.name = "Date"
    else:
        df_pivot = pd.DataFrame(columns=product_names)
        df_pivot.index.name = "Date"

    df_pivot.loc[today] = {name: today_prices.get(name) for name in product_names}
    df_pivot.sort_index(inplace=True)

    wb = Workbook()
    ws = wb.active
    ws.title = SHEET_NAME

    headers = ["Date"] + product_names
    for col_idx, header in enumerate(headers, start=1):
        cell = ws.cell(row=1, column=col_idx, value=header)
        apply_header_style(cell)
        ws.column_dimensions[get_column_letter(col_idx)].width = 18

    for row_idx, (date, row) in enumerate(df_pivot.iterrows(), start=2):
        is_alt    = (row_idx % 2 == 0)
        date_cell = ws.cell(row=row_idx, column=1, value=str(date))
        apply_data_style(date_cell, is_alt)
        for col_idx, name in enumerate(product_names, start=2):
            val        = row.get(name)
            price_cell = ws.cell(
                row=row_idx, column=col_idx,
                value=float(val) if pd.notna(val) else None
            )
            if pd.notna(val):
                price_cell.number_format = '₹#,##0.00'
            apply_data_style(price_cell, is_alt)

    ws.freeze_panes = "A2"
    wb.save(EXCEL_FILE)
    print(f"✅ Pivot data saved to '{EXCEL_FILE}' → sheet '{SHEET_NAME}'")


# ===========================
#  MAIN
# ===========================
product_names = [p["name"] for p in PRODUCTS]
today         = datetime.now().strftime("%Y-%m-%d")

# 1. Read previous prices BEFORE scraping today's
last_prices = get_last_prices(product_names)
print("Previous prices:", last_prices)

# 2. Scrape today's prices
today_prices = {}
for product in PRODUCTS:
    price = get_price(product["url"])
    if price is not None:
        print(f"{product['name']} price: ₹{price:,.2f}")
        today_prices[product["name"]] = price
    else:
        print(f"{product['name']} price not found!")

# 3. Detect drops & send email
drops = []
for product in PRODUCTS:
    name      = product["name"]
    new_price = today_prices.get(name)
    old_price = last_prices.get(name)

    if new_price is None or old_price is None:
        continue  # skip if either price is missing

    if new_price < old_price:
        saving   = old_price - new_price
        pct_drop = (saving / old_price) * 100
        print(f"📉 {name}: ₹{old_price:,.2f} → ₹{new_price:,.2f}  ({pct_drop:.1f}% drop)")
        drops.append({
            "name":      name,
            "url":       product["url"],
            "old_price": old_price,
            "new_price": new_price,
            "saving":    saving,
            "pct_drop":  pct_drop,
        })

send_email_alert(drops)

# 4. Save to Excel
save_pivot_excel(today, today_prices)